package com.vikram.healthmonitoring;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    CircularProgressBar tempBar, oxygenBar, glucoseBar;
    TextView txtTemp, txtOxygen, txtGlucose, txtTempAlert, txtOxygenAlert, txtGlucoseAlert, txtCHD, txtAshtma,
            txtBP, txtPulseRate;
    static int animationDuration = 2500; // 2500ms = 2,5s
    private Context context;
    PrefManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initGUI();
    }

    private void initGUI() {
        context = this;
        prefManager = new PrefManager(this);

        txtBP = findViewById(R.id.txtBP);
        txtPulseRate = findViewById(R.id.txtPulseRate);
        txtPulseRate.setText("");
        txtBP.setText("");
        glucoseBar = (CircularProgressBar) findViewById(R.id.glucoseBar);
        tempBar = (CircularProgressBar) findViewById(R.id.tempBar);
        oxygenBar = (CircularProgressBar) findViewById(R.id.oxygenBar);

        txtTemp = findViewById(R.id.txtTemp);
        txtTempAlert = findViewById(R.id.tempAlert);

        txtGlucose = findViewById(R.id.txtSugarLevel);
        txtGlucoseAlert = findViewById(R.id.glucoseAlert);

        txtOxygen = findViewById(R.id.txtOxygenSaturation);
        txtOxygenAlert = findViewById(R.id.oxygenAlert);
        txtCHD = findViewById(R.id.txtHeartAttackAlert);
        txtAshtma = findViewById(R.id.txtAsthma);
        loadDataFromServer();
    }

    private void loadDataFromServer() {
        final KProgressHUD hud = KProgressHUD.create(this)
                .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                .setLabel("Please wait")
                .show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, ServerUtility.url_get_health_record(),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            final JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.has("success")) {
                                setSugarLevel(jsonObject.getDouble("glucose"));
                                setOxygenLevel(jsonObject.getInt("oxygen_saturation"));
                                setTemp(jsonObject.getDouble("body_temp"));
                                txtBP.setText(jsonObject.getString("systolic_bp")+"/"+jsonObject.getString("diastolic_bp"));
                                txtPulseRate.setText(jsonObject.getString("heart_rate"));
                                predictAsthma(jsonObject.getInt("oxygen_saturation"),jsonObject.getInt("heart_rate"),jsonObject.getInt("raspiration_rate"));
                                predictCHD(jsonObject.getString("chd_prediction"));
                            }
                            hud.dismiss();
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("id", prefManager.getEmpId());
                return params;
            }


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);
    }

    private void setSugarLevel(double sugarlevel) {
        glucoseBar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
        txtGlucose.setText(sugarlevel + " mg/dL");
        if (sugarlevel > 139 && sugarlevel < 200) {
            glucoseBar.setColor(ContextCompat.getColor(this, R.color.yellow));
            txtGlucoseAlert.setText("Indicates prediabetes");
        } else if (sugarlevel >= 200) {
            glucoseBar.setColor(ContextCompat.getColor(this, R.color.red));
            txtGlucoseAlert.setText("Indicates Diabetes");
        } else {
            glucoseBar.setColor(ContextCompat.getColor(this, R.color.green));
            txtGlucoseAlert.setText("Sugar Level is in Control");
        }
        glucoseBar.setProgressWithAnimation((int) sugarlevel / 2, animationDuration); // Default duration = 1500ms
    }

    private void setOxygenLevel(int oxygenLevel) {
        oxygenBar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
        txtOxygen.setText(oxygenLevel + " %");
        //Normal oxygen saturation is usually between 96% and 98%.
        if (oxygenLevel < 99 && oxygenLevel > 95) {
            oxygenBar.setColor(ContextCompat.getColor(this, R.color.green));
            txtOxygenAlert.setText("Normal oxygen saturation");
        } else {
            oxygenBar.setColor(ContextCompat.getColor(this, R.color.red));
            txtOxygenAlert.setText("Dangerous and leads to hypoxemia");
        }
        oxygenBar.setProgressWithAnimation(oxygenLevel, animationDuration); // Default duration = 1500ms
    }

    private void setTemp(double temp) {
        tempBar.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
        txtTemp.setText(temp + " F");
        //Normal oxygen saturation is usually between 96% and 98%.
        if (temp >= 97.8 && temp <= 99) {
            tempBar.setColor(ContextCompat.getColor(this, R.color.green));
            txtTempAlert.setText("Normal bopy temperature");
        } else if (temp > 99) {
            tempBar.setColor(ContextCompat.getColor(this, R.color.red));
            txtTempAlert.setText("abnormal temperature due to fever (high temperature)");
        } else {
            tempBar.setColor(ContextCompat.getColor(this, R.color.red));
            txtTempAlert.setText("Hypothermia (low temperature)");
        }
        tempBar.setProgressWithAnimation((int) temp, animationDuration); // Default duration = 1500ms
    }
    private void predictAsthma(int oxygen,int pulse,int raspiration)
    {
        if((oxygen>=92 && oxygen<=95) && (pulse>=100 && pulse<=125) && (raspiration>=20 && raspiration<=30))
        {
            txtAshtma.setText("Moderate acute asthma");
            txtAshtma.setBackgroundColor(getResources().getColor(R.color.red));
        }
        else
        {
            txtAshtma.setText("No Posibility of Asthma");
            txtAshtma.setBackgroundColor(getResources().getColor(R.color.green));
        }
    }
    private void predictCHD(String ms)
    {
        if(ms.equalsIgnoreCase("no"))
        {
            txtCHD.setText("There is no posibilities of CHD");
            txtCHD.setBackgroundColor(getResources().getColor(R.color.green));
        }else
        {
            txtCHD.setText("There is posibilities of CHD");
            txtCHD.setBackgroundColor(getResources().getColor(R.color.red));
        }
    }
}