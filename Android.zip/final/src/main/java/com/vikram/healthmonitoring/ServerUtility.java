package com.vikram.healthmonitoring;

public class ServerUtility {
//        public static String Server_URL = "http://employe.sortapwadi.com/";
    public static String Server_URL = "http://192.168.43.105:8084/EmployeeHealthServer/";

    public static String url_get_user_info() {
        return Server_URL + "UserLogin";
    }
    public static String url_get_health_record() {
        return Server_URL + "GetMyHealthRecord";
    }


}
