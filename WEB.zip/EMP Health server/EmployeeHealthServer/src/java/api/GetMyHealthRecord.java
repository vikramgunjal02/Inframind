/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package api;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import pack.DBConnection;
import weka.classifiers.Classifier;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.functions.SMO;
import weka.classifiers.trees.J48;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SparseInstance;
import weka.core.converters.CSVLoader;

/**
 *
 * @author PhoenixZone
 */
public class GetMyHealthRecord extends HttpServlet {

    final String filepath = "D:/";
    String inPath = "heart.csv";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            int age, sex, trestbps, chol, heartrate = 0;

            String empID = request.getParameter("id");
            String sql = "SELECT * FROM tbl_health_record INNER JOIN  tbl_employee_details ON  tbl_employee_details.emp_id=tbl_employee_details.emp_id WHERE tbl_employee_details.emp_id='" + empID + "'";
            DBConnection db = new DBConnection();
            ResultSet rs = db.select(sql);
            JSONObject json = new JSONObject();
            if (rs.next()) {
                json.put("glucose", rs.getInt("glucose"));
                json.put("raspiration_rate", rs.getInt("raspiration_rate"));
                json.put("body_temp", rs.getDouble("body_temp"));
                json.put("systolic_bp", rs.getInt("systolic_bp"));
                json.put("diastolic_bp", rs.getInt("diastolic_bp"));
                json.put("heart_rate", rs.getInt("heart_rate"));
                json.put("oxygen_saturation", rs.getInt("oxygen_saturation"));
                age = rs.getInt("emp_age");
                if (rs.getString("emp_gender").equalsIgnoreCase("male")) {
                    sex = 0;
                } else {
                    sex = 1;
                }
                trestbps = rs.getInt("systolic_bp");
                chol = generateRandom(150, 300);
                heartrate = rs.getInt("heart_rate");
                json.put("success", "true");
                json.put("chd_prediction", predictCHD(age, sex, trestbps, chol, heartrate));
            }
            rs.close();
            response.setContentType("application/json");
            response.getWriter().write(json.toString());
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String predictCHD(int age, int sex, int trestbps, int chol, int heartrate) {
        try {
            CSVLoader csv = new CSVLoader();
            csv.setSource(new File(filepath + inPath));
            Instances data = csv.getDataSet();
            data.setClassIndex(data.numAttributes() - 1);
            SMO sm = new SMO();
            sm.buildClassifier(data);

            Instance ins1 = new SparseInstance(4);

            ins1.setValue(0, age);
            ins1.setValue(1, sex);
            ins1.setValue(2, trestbps);
            ins1.setValue(3, chol);
            ins1.setValue(4, heartrate);

            ins1.setDataset(data);

            int r1 = (int) sm.classifyInstance(ins1);
            System.out.println(r1);

            String cs[] = sm.classAttributeNames();
            String ms = cs[r1];
            return ms;
        } catch (Exception e) {
            return "";
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private int generateRandom(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }
}
