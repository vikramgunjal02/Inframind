/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pack.DBConnection;

/**
 *
 * @author PhoenixZone
 */
public class AddEmployee extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            DBConnection db = new DBConnection();
            String email = request.getParameter("emp_email");
            String mobile = request.getParameter("emp_mobile");
            String address = request.getParameter("address");
            String name = request.getParameter("emp_name");
            String department = request.getParameter("emp_department");
            String empID = request.getParameter("emp_id");
            String age = request.getParameter("emp_age");
            String gender = request.getParameter("emp_gender");
            String emp_pk_id = request.getParameter("emp_pk_id");
            if (emp_pk_id != "") {
                String sql = "UPDATE tbl_employee_details SET emp_name='" + name + "',emp_mobile='" + mobile + "',"
                        + "emp_address='" + address + "',emp_age=" + age + ",emp_gender='" + gender + "',emp_id='" + empID + "',"
                        + "emp_email='" + email + "',emp_department='" + department + "' WHERE emp_pk_id=" + emp_pk_id;
                int row_affected = db.update(sql);
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Record Updated Successfully..!');");
                out.println("location='view_employee.jsp';");
                out.println("</script>");
            } else {
                //generate 6char password
                String password = generateRandomPassword(6);

                String sql = "SELECT * FROM tbl_employee_details WHERE emp_email='" + email + "'";
                ResultSet rs = db.select(sql);
                if (rs.next()) {
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('Email Already in Use!');");
                    out.println("location='view_employee.jsp';");
                    out.println("</script>");
                } else {

                    //insert into table
                    sql = "INSERT INTO tbl_employee_details(emp_id,emp_name,emp_mobile,emp_email,emp_password,"
                            + "emp_address,emp_department,emp_age,emp_gender) VALUES('" + empID + "','" + name + "','" + mobile + "','" + email + "',"
                            + "'" + password + "','" + address + "','" + department + "'," + age + ",'" + gender + "')";
                    int row_affected = db.update(sql);
                    if (row_affected > 0) {
                         sql="INSERT INTO tbl_health_record(emp_id) VALUES('"+empID+"')";
                        db.update(sql);
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Employee Details Added!');");
                        out.println("location='view_employee.jsp';");
                        out.println("</script>");
                    } else {
                        out.println("<script type=\"text/javascript\">");
                        out.println("alert('Failed to Add!');");
                        out.println("location='view_employee.jsp';");
                        out.println("</script>");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    // Function to generate random alpha-numeric password of specific length

    public static String generateRandomPassword(int len) {
        // ASCII range - alphanumeric (0-9, a-z, A-Z)
        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder();

        // each iteration of loop choose a character randomly from the given ASCII range
        // and append it to StringBuilder instance
        for (int i = 0; i < len; i++) {
            int randomIndex = random.nextInt(chars.length());
            sb.append(chars.charAt(randomIndex));
        }

        return sb.toString();
    }

}
